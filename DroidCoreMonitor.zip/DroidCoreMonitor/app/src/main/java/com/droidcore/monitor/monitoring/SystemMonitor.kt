package com.droidcore.monitor.monitoring

import android.app.ActivityManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.input.InputManager
import android.hardware.usb.UsbManager
import android.location.LocationManager
import android.media.AudioManager
import android.media.MediaCodecList
import android.media.MediaDrm
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.telephony.TelephonyManager
import android.util.DisplayMetrics
import android.view.InputDevice
import android.view.WindowManager
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.io.RandomAccessFile
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.UUID
import kotlin.math.roundToInt

class SystemMonitor(private val context: Context) {

    private var lastRxBytes = TrafficStats.getTotalRxBytes()
    private var lastTxBytes = TrafficStats.getTotalTxBytes()
    private var lastTime = System.currentTimeMillis()

    fun getRamInfo(): Map<String, String> {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)

        val totalRam = memoryInfo.totalMem
        val availRam = memoryInfo.availMem
        val usedRam = totalRam - availRam
        val percentage = ((usedRam.toDouble() / totalRam.toDouble()) * 100).toInt()

        return mapOf(
            "Total RAM" to formatSize(totalRam),
            "Used RAM" to formatSize(usedRam),
            "Free RAM" to formatSize(availRam),
            "Percentage" to "$percentage%",
            "Low Memory State" to if (memoryInfo.lowMemory) "Yes" else "No"
        )
    }

    fun getStorageInfo(): Map<String, String> {
        val path = Environment.getDataDirectory()
        val stat = StatFs(path.path)
        val blockSize = stat.blockSizeLong
        val totalBlocks = stat.blockCountLong
        val availableBlocks = stat.availableBlocksLong

        val totalSize = totalBlocks * blockSize
        val availableSize = availableBlocks * blockSize
        val usedSize = totalSize - availableSize
        val percentage = if (totalSize > 0) ((usedSize.toDouble() / totalSize.toDouble()) * 100).toInt() else 0

        return mapOf(
            "Internal Total" to formatSize(totalSize),
            "Internal Used" to formatSize(usedSize),
            "Internal Free" to formatSize(availableSize),
            "Percentage" to "$percentage%"
        )
    }

    fun getBatteryInfo(): Map<String, String> {
        val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus = context.registerReceiver(null, intentFilter)

        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = if (scale > 0) (level * 100 / scale.toFloat()).toInt() else 0

        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val chargePlug = batteryStatus?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
        val usbCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_USB
        val acCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_AC
        val wirelessCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_WIRELESS

        val temp = (batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val voltage = batteryStatus?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val tech = batteryStatus?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Unknown"

        val healthInt = batteryStatus?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1
        val health = when (healthInt) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            else -> "Unknown"
        }

        return mapOf(
            "Percentage" to "$batteryPct%",
            "Status" to if (isCharging) "Charging" else "Discharging",
            "Health" to health,
            "Power Source" to if (usbCharge) "USB" else if (acCharge) "AC" else if (wirelessCharge) "Wireless" else "Battery",
            "Temperature" to "$temp °C",
            "Voltage" to "${voltage}mV",
            "Technology" to tech
        )
    }

    fun getNetworkInfo(): Map<String, String> {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val capabilities = cm.getNetworkCapabilities(network)

        val type = when {
            capabilities == null -> "No Network"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile Data"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "Unknown"
        }

        val currentRx = TrafficStats.getTotalRxBytes()
        val currentTx = TrafficStats.getTotalTxBytes()
        val currentTime = System.currentTimeMillis()

        val timeDiff = (currentTime - lastTime) / 1000.0
        val rxSpeed = if (timeDiff > 0) ((currentRx - lastRxBytes) / timeDiff).toLong() else 0L
        val txSpeed = if (timeDiff > 0) ((currentTx - lastTxBytes) / timeDiff).toLong() else 0L

        lastRxBytes = currentRx
        lastTxBytes = currentTx
        lastTime = currentTime

        return mapOf(
            "Type" to type,
            "Download Speed" to "${formatSpeed(rxSpeed)}/s",
            "Upload Speed" to "${formatSpeed(txSpeed)}/s",
            "IP Address" to getLocalIpAddress()
        )
    }

    fun getCpuInfo(): Map<String, String> {
        val cores = Runtime.getRuntime().availableProcessors()
        var currentFreq = 0L
        var maxFreq = 0L

        try {
            val curReader = RandomAccessFile("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq", "r")
            currentFreq = curReader.readLine().toLong()
            curReader.close()

            val maxReader = RandomAccessFile("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq", "r")
            maxFreq = maxReader.readLine().toLong()
            maxReader.close()
        } catch (e: Exception) {
            // Fallback
        }

        val usagePct = if (maxFreq > 0) ((currentFreq.toDouble() / maxFreq.toDouble()) * 100).toInt() else 0

        val data = mutableMapOf(
            "Available Cores" to cores.toString(),
            "Usage" to "$usagePct%",
            "Supported ABIs" to Build.SUPPORTED_ABIS.joinToString(", ")
        )

        if (currentFreq > 0) {
            data["Current Frequency"] = "${currentFreq / 1000} MHz"
            data["Max Frequency"] = "${maxFreq / 1000} MHz"
        }

        return data
    }

    fun getDeviceInfo(): Map<String, String> {
        val uptimeMillis = SystemClock.elapsedRealtime()
        val uptimeHours = uptimeMillis / (1000 * 60 * 60)
        val uptimeMinutes = (uptimeMillis / (1000 * 60)) % 60

        val data = mutableMapOf(
            "Model" to Build.MODEL,
            "Brand" to Build.BRAND,
            "Manufacturer" to Build.MANUFACTURER,
            "Android Version" to Build.VERSION.RELEASE,
            "SDK Level" to Build.VERSION.SDK_INT.toString(),
            "Hardware" to Build.HARDWARE,
            "Board" to Build.BOARD,
            "Device" to Build.DEVICE,
            "System Uptime" to "${uptimeHours}h ${uptimeMinutes}m"
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            data["Security Patch"] = Build.VERSION.SECURITY_PATCH
        }

        return data
    }

    fun getDisplayInfo(): Map<String, String> {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val display = context.display
            display?.getRealMetrics(metrics)
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)
        }

        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val densityDpi = metrics.densityDpi
        
        var refreshRate = 60.0f
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            refreshRate = context.display?.refreshRate ?: 60.0f
        } else {
            @Suppress("DEPRECATION")
            refreshRate = windowManager.defaultDisplay.refreshRate
        }

        return mapOf(
            "Resolution" to "${width}x${height} px",
            "Density" to "$densityDpi dpi",
            "Refresh Rate" to String.format("%.1f Hz", refreshRate)
        )
    }

    fun getSensorsInfo(): Map<String, String> {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensors = sensorManager.getSensorList(Sensor.TYPE_ALL)
        
        val hasAccelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null
        val hasGyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null
        val hasProximity = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY) != null
        val hasLight = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT) != null

        return mapOf(
            "Total Sensors" to sensors.size.toString(),
            "Accelerometer" to if (hasAccelerometer) "Available" else "Not Available",
            "Gyroscope" to if (hasGyroscope) "Available" else "Not Available",
            "Proximity Sensor" to if (hasProximity) "Available" else "Not Available",
            "Light Sensor" to if (hasLight) "Available" else "Not Available"
        )
    }

    fun getCameraInfo(): Map<String, String> {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val data = mutableMapOf<String, String>()
        
        try {
            val cameraIdList = cameraManager.cameraIdList
            data["Total Cameras"] = cameraIdList.size.toString()
            
            for (cameraId in cameraIdList) {
                val characteristics = cameraManager.getCameraCharacteristics(cameraId)
                val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                val hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
                
                val activeArraySize = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
                val megapixels = if (activeArraySize != null) {
                    ((activeArraySize.width() * activeArraySize.height()) / 1000000.0).roundToInt()
                } else 0
                
                val facingStr = when (facing) {
                    CameraCharacteristics.LENS_FACING_FRONT -> "Front"
                    CameraCharacteristics.LENS_FACING_BACK -> "Back"
                    CameraCharacteristics.LENS_FACING_EXTERNAL -> "External"
                    else -> "Unknown"
                }
                
                data["Camera $cameraId ($facingStr)"] = "$megapixels MP"
                data["Camera $cameraId Flash"] = if (hasFlash) "Supported" else "Not Supported"
            }
        } catch (e: Exception) {
            data["Status"] = "Camera Info Unavailable"
        }
        
        return data
    }

    fun getSimInfo(): Map<String, String> {
        val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        
        val simState = when (telephonyManager.simState) {
            TelephonyManager.SIM_STATE_ABSENT -> "Absent"
            TelephonyManager.SIM_STATE_NETWORK_LOCKED -> "Network Locked"
            TelephonyManager.SIM_STATE_PIN_REQUIRED -> "PIN Required"
            TelephonyManager.SIM_STATE_PUK_REQUIRED -> "PUK Required"
            TelephonyManager.SIM_STATE_READY -> "Ready"
            TelephonyManager.SIM_STATE_UNKNOWN -> "Unknown"
            else -> "Unknown"
        }

        val phoneType = when (telephonyManager.phoneType) {
            TelephonyManager.PHONE_TYPE_CDMA -> "CDMA"
            TelephonyManager.PHONE_TYPE_GSM -> "GSM"
            TelephonyManager.PHONE_TYPE_SIP -> "SIP"
            TelephonyManager.PHONE_TYPE_NONE -> "None"
            else -> "Unknown"
        }

        return mapOf(
            "SIM State" to simState,
            "Operator Name" to (telephonyManager.simOperatorName.takeIf { it.isNotEmpty() } ?: "Unknown"),
            "Country ISO" to (telephonyManager.simCountryIso.takeIf { it.isNotEmpty() }?.uppercase() ?: "Unknown"),
            "Phone Type" to phoneType
        )
    }

    fun getAudioInfo(): Map<String, String> {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        
        val maxMusic = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val currentMusic = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        
        val maxRing = audioManager.getStreamMaxVolume(AudioManager.STREAM_RING)
        val currentRing = audioManager.getStreamVolume(AudioManager.STREAM_RING)
        
        val maxAlarm = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
        val currentAlarm = audioManager.getStreamVolume(AudioManager.STREAM_ALARM)

        val ringerMode = when (audioManager.ringerMode) {
            AudioManager.RINGER_MODE_NORMAL -> "Normal"
            AudioManager.RINGER_MODE_SILENT -> "Silent"
            AudioManager.RINGER_MODE_VIBRATE -> "Vibrate"
            else -> "Unknown"
        }

        return mapOf(
            "Ringer Mode" to ringerMode,
            "Media Volume" to "$currentMusic / $maxMusic",
            "Ring Volume" to "$currentRing / $maxRing",
            "Alarm Volume" to "$currentAlarm / $maxAlarm"
        )
    }

    fun getBluetoothInfo(): Map<String, String> {
        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = bluetoothManager.adapter
        
        val isSupported = adapter != null
        val isEnabled = adapter?.isEnabled == true
        
        return mapOf(
            "Supported" to if (isSupported) "Yes" else "No",
            "Status" to if (isEnabled) "Enabled" else "Disabled",
            "Name" to (adapter?.name ?: "Unknown")
        )
    }

    fun getFeaturesInfo(): Map<String, String> {
        val pm = context.packageManager
        val hasNfc = pm.hasSystemFeature(PackageManager.FEATURE_NFC)
        val hasFingerprint = pm.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)
        val hasFace = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            pm.hasSystemFeature(PackageManager.FEATURE_FACE)
        } else {
            pm.hasSystemFeature("android.hardware.biometrics.face")
        }
        val hasIr = pm.hasSystemFeature(PackageManager.FEATURE_CONSUMER_IR)

        return mapOf(
            "NFC Support" to if (hasNfc) "Available" else "Not Available",
            "Fingerprint Scanner" to if (hasFingerprint) "Available" else "Not Available",
            "Face Unlock" to if (hasFace) "Available" else "Not Available",
            "IR Blaster (Remote)" to if (hasIr) "Available" else "Not Available"
        )
    }

    fun getAppsInfo(): Map<String, String> {
        val pm = context.packageManager
        val packages = pm.getInstalledPackages(0)
        var systemApps = 0
        var userApps = 0

        for (p in packages) {
            if ((p.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0) {
                systemApps++
            } else {
                userApps++
            }
        }

        return mapOf(
            "Total Apps" to packages.size.toString(),
            "System Apps" to systemApps.toString(),
            "User Apps" to userApps.toString()
        )
    }

    fun getGpuInfo(): Map<String, String> {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val configInfo = activityManager.deviceConfigurationInfo
        val glEsVersion = configInfo.glEsVersion

        return mapOf(
            "OpenGL ES Version" to glEsVersion
        )
    }

    fun getLocationInfo(): Map<String, String> {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        val isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

        return mapOf(
            "GPS Provider" to if (isGpsEnabled) "Enabled" else "Disabled",
            "Network Provider" to if (isNetworkEnabled) "Enabled" else "Disabled"
        )
    }

    fun getDrmInfo(): Map<String, String> {
        val WIDEVINE_UUID = UUID(-0x121074568629b532L, -0x5c37d8232ae2de13L)
        var securityLevel = "Unknown"
        var systemId = "Unknown"
        
        try {
            val mediaDrm = MediaDrm(WIDEVINE_UUID)
            securityLevel = mediaDrm.getPropertyString("securityLevel")
            systemId = mediaDrm.getPropertyString("systemId")
            mediaDrm.close()
        } catch (e: Exception) {
            securityLevel = "Unsupported"
        }

        return mapOf(
            "Widevine Security Level" to securityLevel,
            "System ID" to systemId
        )
    }

    fun getCodecInfo(): Map<String, String> {
        val codecList = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
        var videoDecoders = 0
        var audioDecoders = 0
        
        for (codec in codecList) {
            if (!codec.isEncoder) {
                val types = codec.supportedTypes
                if (types.any { it.startsWith("video/") }) videoDecoders++
                if (types.any { it.startsWith("audio/") }) audioDecoders++
            }
        }
        
        return mapOf(
            "Total Codecs" to codecList.size.toString(),
            "Video Decoders" to videoDecoders.toString(),
            "Audio Decoders" to audioDecoders.toString()
        )
    }

    fun getRootInfo(): Map<String, String> {
        val buildTags = Build.TAGS
        val isTestKeys = buildTags != null && buildTags.contains("test-keys")
        val paths = arrayOf(
            "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su",
            "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su",
            "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/su"
        )
        var hasSuFile = false
        for (path in paths) {
            if (File(path).exists()) {
                hasSuFile = true
                break
            }
        }
        val isRooted = isTestKeys || hasSuFile
        return mapOf(
            "Root Access" to if (isRooted) "Rooted" else "Not Rooted",
            "Test Keys" to if (isTestKeys) "Present" else "Absent",
            "SU Binary" to if (hasSuFile) "Found" else "Not Found"
        )
    }

    fun getThermalInfo(): Map<String, String> {
        val thermals = mutableMapOf<String, String>()
        try {
            val dir = File("/sys/class/thermal/")
            if (dir.exists()) {
                val files = dir.listFiles()?.filter { it.name.startsWith("thermal_zone") }
                var count = 0
                files?.forEach { zone ->
                    val typeFile = File(zone, "type")
                    val tempFile = File(zone, "temp")
                    if (typeFile.exists() && tempFile.exists()) {
                        val type = typeFile.readText().trim()
                        val tempStr = tempFile.readText().trim()
                        val temp = tempStr.toFloatOrNull()
                        if (temp != null && temp > 0) {
                            val actualTemp = if (temp > 1000) temp / 1000.0f else temp
                            thermals[type] = String.format("%.1f °C", actualTemp)
                            count++
                        }
                    }
                }
                thermals["Total Zones"] = count.toString()
            }
        } catch (e: Exception) {
            thermals["Status"] = "Unavailable"
        }
        if (thermals.isEmpty()) thermals["Status"] = "No Thermal Data"
        return thermals
    }

    fun getSwapInfo(): Map<String, String> {
        var swapTotal = 0L
        var swapFree = 0L
        try {
            val reader = BufferedReader(FileReader("/proc/meminfo"))
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                if (line!!.startsWith("SwapTotal:")) {
                    val parts = line!!.split(Regex("\\s+"))
                    swapTotal = parts[1].toLong() * 1024 // in bytes
                } else if (line!!.startsWith("SwapFree:")) {
                    val parts = line!!.split(Regex("\\s+"))
                    swapFree = parts[1].toLong() * 1024 // in bytes
                }
            }
            reader.close()
        } catch (e: Exception) {
            // Ignore
        }
        val swapUsed = swapTotal - swapFree
        val percentage = if (swapTotal > 0) ((swapUsed.toDouble() / swapTotal.toDouble()) * 100).toInt() else 0
        return mapOf(
            "Total Swap" to formatSize(swapTotal),
            "Used Swap" to formatSize(swapUsed),
            "Free Swap" to formatSize(swapFree),
            "Percentage" to "$percentage%"
        )
    }

    fun getWifiDetailsInfo(): Map<String, String> {
        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wifiManager.connectionInfo
        val state = wifiManager.wifiState
        val stateStr = when(state) {
            WifiManager.WIFI_STATE_ENABLED -> "Enabled"
            WifiManager.WIFI_STATE_DISABLED -> "Disabled"
            WifiManager.WIFI_STATE_ENABLING -> "Enabling"
            WifiManager.WIFI_STATE_DISABLING -> "Disabling"
            else -> "Unknown"
        }
        val linkSpeed = info.linkSpeed
        val rssi = info.rssi
        val freq = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) info.frequency else 0
        
        return mapOf(
            "Wi-Fi State" to stateStr,
            "Link Speed" to "${linkSpeed} Mbps",
            "Signal Strength (RSSI)" to "${rssi} dBm",
            "Frequency" to "${freq} MHz",
            "MAC Address" to (info.macAddress ?: "Unknown")
        )
    }

    fun getUsbInfo(): Map<String, String> {
        val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
        val hasUsbHost = context.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)
        val deviceList = try { usbManager.deviceList } catch(e: Exception) { emptyMap() }
        
        return mapOf(
            "USB Host (OTG) Support" to if (hasUsbHost) "Yes" else "No",
            "Connected USB Devices" to deviceList.size.toString()
        )
    }

    fun getInputDevicesInfo(): Map<String, String> {
        val inputManager = context.getSystemService(Context.INPUT_SERVICE) as InputManager
        val devices = inputManager.inputDeviceIds
        var keyboards = 0
        var mice = 0
        var touchscreens = 0
        
        for (id in devices) {
            val device = inputManager.getInputDevice(id)
            if (device != null) {
                if (device.sources and InputDevice.SOURCE_KEYBOARD == InputDevice.SOURCE_KEYBOARD) keyboards++
                if (device.sources and InputDevice.SOURCE_MOUSE == InputDevice.SOURCE_MOUSE) mice++
                if (device.sources and InputDevice.SOURCE_TOUCHSCREEN == InputDevice.SOURCE_TOUCHSCREEN) touchscreens++
            }
        }
        
        return mapOf(
            "Total Input Devices" to devices.size.toString(),
            "Keyboards" to keyboards.toString(),
            "Mice" to mice.toString(),
            "Touchscreens" to touchscreens.toString()
        )
    }

    fun getJvmInfo(): Map<String, String> {
        val runtime = Runtime.getRuntime()
        val maxMemory = runtime.maxMemory()
        val totalMemory = runtime.totalMemory()
        val freeMemory = runtime.freeMemory()
        val usedMemory = totalMemory - freeMemory

        return mapOf(
            "Java Version" to (System.getProperty("java.version") ?: "Unknown"),
            "Java Vendor" to (System.getProperty("java.vendor") ?: "Unknown"),
            "VM Name" to (System.getProperty("java.vm.name") ?: "Unknown"),
            "VM Version" to (System.getProperty("java.vm.version") ?: "Unknown"),
            "Max Heap Size" to formatSize(maxMemory),
            "Total Allocated" to formatSize(totalMemory),
            "Used Heap" to formatSize(usedMemory),
            "Free Heap" to formatSize(freeMemory)
        )
    }

    fun getPartitionsInfo(): Map<String, String> {
        val data = mutableMapOf<String, String>()
        val paths = listOf(
            "System" to Environment.getRootDirectory(),
            "Data" to Environment.getDataDirectory(),
            "Cache" to Environment.getDownloadCacheDirectory()
        )

        for ((name, file) in paths) {
            try {
                val stat = StatFs(file.path)
                val total = stat.blockCountLong * stat.blockSizeLong
                val free = stat.availableBlocksLong * stat.blockSizeLong
                val used = total - free
                data["$name Total"] = formatSize(total)
                data["$name Used"] = formatSize(used)
                data["$name Free"] = formatSize(free)
            } catch (e: Exception) {
                data[name] = "Unavailable"
            }
        }
        return data
    }

    fun getEnvInfo(): Map<String, String> {
        val envs = System.getenv()
        val data = mutableMapOf<String, String>()
        
        val keysToFetch = listOf("PATH", "LD_LIBRARY_PATH", "ANDROID_ROOT", "ANDROID_DATA", "EXTERNAL_STORAGE")
        for (key in keysToFetch) {
            data[key] = envs[key] ?: "Not Set"
        }
        data["Total Variables"] = envs.size.toString()
        return data
    }

    private fun getLocalIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val intf = interfaces.nextElement()
                val addrs = intf.inetAddresses
                while (addrs.hasMoreElements()) {
                    val addr = addrs.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress ?: "Unavailable"
                    }
                }
            }
        } catch (e: Exception) {
            // Ignore
        }
        return "Unavailable"
    }

    private fun formatSize(size: Long): String {
        val kb = 1024.0
        val mb = kb * 1024
        val gb = mb * 1024
        return when {
            size >= gb -> String.format("%.2f GB", size / gb)
            size >= mb -> String.format("%.2f MB", size / mb)
            size >= kb -> String.format("%.2f KB", size / kb)
            else -> "$size B"
        }
    }

    private fun formatSpeed(size: Long): String {
        val kb = 1024.0
        val mb = kb * 1024
        return when {
            size >= mb -> String.format("%.2f MB", size / mb)
            size >= kb -> String.format("%.2f KB", size / kb)
            else -> "$size B"
        }
    }
}
