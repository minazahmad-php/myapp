package com.droidcore.monitor

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.droidcore.monitor.adapters.DashboardAdapter
import com.droidcore.monitor.databinding.ActivityMainBinding
import com.droidcore.monitor.viewmodel.MonitorViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MonitorViewModel by viewModels()
    private lateinit var adapter: DashboardAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()

        viewModel.startMonitoring(this)
        viewModel.dashboardItems.observe(this) { items ->
            adapter.submitList(items)
        }
    }

    private fun setupRecyclerView() {
        adapter = DashboardAdapter { clickedTitle ->
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra("TYPE", clickedTitle)
            startActivity(intent)
        }
        // 2 columns grid for dashboard
        binding.rvDashboard.layoutManager = GridLayoutManager(this, 2)
        binding.rvDashboard.adapter = adapter
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.stopMonitoring()
    }
}
