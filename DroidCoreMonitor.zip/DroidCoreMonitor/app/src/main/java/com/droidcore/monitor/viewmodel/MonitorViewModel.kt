package com.droidcore.monitor.viewmodel

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.droidcore.monitor.R
import com.droidcore.monitor.adapters.DashboardItem
import com.droidcore.monitor.monitoring.SystemMonitor
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MonitorViewModel : ViewModel() {

    private val _dashboardItems = MutableLiveData<List<DashboardItem>>()
    val dashboardItems: LiveData<List<DashboardItem>> = _dashboardItems

    private val _detailData = MutableLiveData<Map<String, Map<String, String>>>()
    val detailData: LiveData<Map<String, Map<String, String>>> = _detailData

    private var monitorJob: Job? = null

    fun startMonitoring(context: Context) {
        if (monitorJob?.isActive == true) return
        val monitor = SystemMonitor(context.applicationContext)
        
        monitorJob = viewModelScope.launch {
            while (isActive) {
                val ramData = monitor.getRamInfo()
                val storageData = monitor.getStorageInfo()
                val batteryData = monitor.getBatteryInfo()
                val networkData = monitor.getNetworkInfo()
                val cpuData = monitor.getCpuInfo()
                val deviceInfo = monitor.getDeviceInfo()
                val displayInfo = monitor.getDisplayInfo()
                val sensorsInfo = monitor.getSensorsInfo()
                val cameraInfo = monitor.getCameraInfo()
                val simInfo = monitor.getSimInfo()
                val audioInfo = monitor.getAudioInfo()
                val bluetoothInfo = monitor.getBluetoothInfo()
                val featuresInfo = monitor.getFeaturesInfo()
                val appsInfo = monitor.getAppsInfo()
                val gpuInfo = monitor.getGpuInfo()
                val locationInfo = monitor.getLocationInfo()
                val drmInfo = monitor.getDrmInfo()
                val codecInfo = monitor.getCodecInfo()
                val rootInfo = monitor.getRootInfo()
                val thermalInfo = monitor.getThermalInfo()
                val swapInfo = monitor.getSwapInfo()
                val wifiDetailsInfo = monitor.getWifiDetailsInfo()
                val usbInfo = monitor.getUsbInfo()
                val inputInfo = monitor.getInputDevicesInfo()
                val jvmInfo = monitor.getJvmInfo()
                val partitionsInfo = monitor.getPartitionsInfo()
                val envInfo = monitor.getEnvInfo()

                val items = listOf(
                    DashboardItem(
                        "RAM", 
                        ramData["Percentage"]?.replace("%", "")?.toIntOrNull() ?: 0, 
                        "${ramData["Used RAM"]} / ${ramData["Total RAM"]}",
                        R.drawable.ic_ram
                    ),
                    DashboardItem(
                        "Swap", 
                        swapInfo["Percentage"]?.replace("%", "")?.toIntOrNull() ?: 0, 
                        "${swapInfo["Used Swap"]} / ${swapInfo["Total Swap"]}",
                        R.drawable.ic_swap
                    ),
                    DashboardItem(
                        "Storage", 
                        storageData["Percentage"]?.replace("%", "")?.toIntOrNull() ?: 0, 
                        "${storageData["Internal Used"]} / ${storageData["Internal Total"]}",
                        R.drawable.ic_storage
                    ),
                    DashboardItem(
                        "Partitions", 
                        100, 
                        "Sys: ${partitionsInfo["System Total"] ?: "N/A"}",
                        R.drawable.ic_partitions
                    ),
                    DashboardItem(
                        "Battery", 
                        batteryData["Percentage"]?.replace("%", "")?.toIntOrNull() ?: 0, 
                        batteryData["Status"] ?: "",
                        R.drawable.ic_battery
                    ),
                    DashboardItem(
                        "Network", 
                        100, 
                        "↓ ${networkData["Download Speed"]}  ↑ ${networkData["Upload Speed"]}",
                        R.drawable.ic_network
                    ),
                    DashboardItem(
                        "Wi-Fi", 
                        100, 
                        "${wifiDetailsInfo["Link Speed"]}",
                        R.drawable.ic_wifi_details
                    ),
                    DashboardItem(
                        "CPU", 
                        cpuData["Usage"]?.replace("%", "")?.toIntOrNull() ?: 0, 
                        "${cpuData["Available Cores"]} Cores Active",
                        R.drawable.ic_cpu
                    ),
                    DashboardItem(
                        "Thermal", 
                        100, 
                        "${thermalInfo["Total Zones"] ?: "0"} Zones",
                        R.drawable.ic_thermal
                    ),
                    DashboardItem(
                        "Display", 
                        100, 
                        displayInfo["Resolution"] ?: "",
                        R.drawable.ic_display
                    ),
                    DashboardItem(
                        "Camera", 
                        100, 
                        "${cameraInfo["Total Cameras"]} Cameras",
                        R.drawable.ic_camera
                    ),
                    DashboardItem(
                        "Audio", 
                        100, 
                        "Mode: ${audioInfo["Ringer Mode"]}",
                        R.drawable.ic_audio
                    ),
                    DashboardItem(
                        "SIM", 
                        100, 
                        simInfo["Operator Name"] ?: "Unknown",
                        R.drawable.ic_sim
                    ),
                    DashboardItem(
                        "Bluetooth", 
                        100, 
                        "Status: ${bluetoothInfo["Status"]}",
                        R.drawable.ic_bluetooth
                    ),
                    DashboardItem(
                        "Features", 
                        100, 
                        "NFC: ${featuresInfo["NFC Support"]}",
                        R.drawable.ic_features
                    ),
                    DashboardItem(
                        "Apps", 
                        100, 
                        "${appsInfo["Total Apps"]} Installed",
                        R.drawable.ic_apps
                    ),
                    DashboardItem(
                        "Sensors", 
                        100, 
                        "${sensorsInfo["Total Sensors"]} Sensors found",
                        R.drawable.ic_sensor
                    ),
                    DashboardItem(
                        "GPU", 
                        100, 
                        "OpenGL: ${gpuInfo["OpenGL ES Version"]}",
                        R.drawable.ic_gpu
                    ),
                    DashboardItem(
                        "Location", 
                        100, 
                        "GPS: ${locationInfo["GPS Provider"]}",
                        R.drawable.ic_location
                    ),
                    DashboardItem(
                        "DRM", 
                        100, 
                        "Widevine: ${drmInfo["Widevine Security Level"]}",
                        R.drawable.ic_drm
                    ),
                    DashboardItem(
                        "Codecs", 
                        100, 
                        "${codecInfo["Total Codecs"]} Supported",
                        R.drawable.ic_codec
                    ),
                    DashboardItem(
                        "USB", 
                        100, 
                        "${usbInfo["Connected USB Devices"]} Devices",
                        R.drawable.ic_usb
                    ),
                    DashboardItem(
                        "Input", 
                        100, 
                        "${inputInfo["Total Input Devices"]} Devices",
                        R.drawable.ic_input
                    ),
                    DashboardItem(
                        "JVM", 
                        100, 
                        "Heap: ${jvmInfo["Max Heap Size"]}",
                        R.drawable.ic_jvm
                    ),
                    DashboardItem(
                        "Environment", 
                        100, 
                        "${envInfo["Total Variables"]} Variables",
                        R.drawable.ic_env
                    ),
                    DashboardItem(
                        "Root", 
                        100, 
                        rootInfo["Root Access"] ?: "Not Rooted",
                        R.drawable.ic_root
                    ),
                    DashboardItem(
                        "Device", 
                        100, 
                        deviceInfo["Model"] ?: "",
                        R.drawable.ic_device
                    )
                )
                _dashboardItems.postValue(items)

                val details = mapOf(
                    "RAM" to ramData,
                    "Swap" to swapInfo,
                    "Storage" to storageData,
                    "Partitions" to partitionsInfo,
                    "Battery" to batteryData,
                    "Network" to networkData,
                    "Wi-Fi" to wifiDetailsInfo,
                    "CPU" to cpuData,
                    "Thermal" to thermalInfo,
                    "Display" to displayInfo,
                    "Camera" to cameraInfo,
                    "Audio" to audioInfo,
                    "SIM" to simInfo,
                    "Bluetooth" to bluetoothInfo,
                    "Features" to featuresInfo,
                    "Apps" to appsInfo,
                    "Sensors" to sensorsInfo,
                    "GPU" to gpuInfo,
                    "Location" to locationInfo,
                    "DRM" to drmInfo,
                    "Codecs" to codecInfo,
                    "USB" to usbInfo,
                    "Input" to inputInfo,
                    "JVM" to jvmInfo,
                    "Environment" to envInfo,
                    "Root" to rootInfo,
                    "Device" to deviceInfo
                )
                _detailData.postValue(details)

                delay(1000) // Update every 1 second
            }
        }
    }

    fun stopMonitoring() {
        monitorJob?.cancel()
    }
}
