package com.droidcore.monitor

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.droidcore.monitor.adapters.DetailAdapter
import com.droidcore.monitor.databinding.ActivityDetailBinding
import com.droidcore.monitor.viewmodel.MonitorViewModel

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private val viewModel: MonitorViewModel by viewModels()
    private lateinit var adapter: DetailAdapter
    private var type: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        type = intent.getStringExtra("TYPE") ?: ""
        binding.tvDetailTitle.text = type

        binding.btnBack.setOnClickListener {
            finish()
        }

        setupRecyclerView()

        viewModel.startMonitoring(this)
        viewModel.detailData.observe(this) { dataMap ->
            if (dataMap.containsKey(type)) {
                val detailsList = dataMap[type]!!.toList()
                adapter.submitList(detailsList)
            }
        }
    }

    private fun setupRecyclerView() {
        adapter = DetailAdapter()
        binding.rvDetails.layoutManager = LinearLayoutManager(this)
        binding.rvDetails.adapter = adapter
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.stopMonitoring()
    }
}
