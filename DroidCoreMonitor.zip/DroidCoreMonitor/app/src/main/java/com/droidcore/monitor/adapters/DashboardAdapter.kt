package com.droidcore.monitor.adapters

import android.os.Build
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.droidcore.monitor.databinding.ItemDashboardCardBinding

data class DashboardItem(
    val title: String,
    val percentage: Int,
    val valueText: String,
    val iconResId: Int
)

class DashboardAdapter(private val onClick: (String) -> Unit) :
    ListAdapter<DashboardItem, DashboardAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemDashboardCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(private val binding: ItemDashboardCardBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: DashboardItem) {
            binding.tvCardTitle.text = item.title
            binding.ivIcon.setImageResource(item.iconResId)
            binding.tvPercentage.text = "${item.percentage}%"
            binding.tvValue.text = item.valueText
            
            // Smooth progress animation for API 24+
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                binding.progressBar.setProgress(item.percentage, true)
            } else {
                binding.progressBar.progress = item.percentage
            }
            
            binding.root.setOnClickListener { onClick(item.title) }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<DashboardItem>() {
        override fun areItemsTheSame(oldItem: DashboardItem, newItem: DashboardItem) = oldItem.title == newItem.title
        override fun areContentsTheSame(oldItem: DashboardItem, newItem: DashboardItem) = oldItem == newItem
    }
}
